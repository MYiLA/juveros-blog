=== Plugin Name ===
Contributors: bfintal, ShapingRain
Tags: framework, options, admin, admin panel, meta box, theme customizer, option framework, library, sdk, edd, settings, api, theme creator, theme framework
Requires at least: 4.1
Tested up to: 4.9.7
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create Settings for Your WordPress Themes & Plugins with Just a Few Lines of Code.

== Description ==

ShapingRain Framework is a fork of the Titan Framework and provides backend features for ShapingRain WordPress themes.