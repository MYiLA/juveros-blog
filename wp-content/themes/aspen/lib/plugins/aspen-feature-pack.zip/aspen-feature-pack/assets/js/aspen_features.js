/*
Aspen Features Init Scripts
 */

(function ($, window, undefined) {
	"use strict";

	$('.sharing-box').hcSticky({
		stickTo: '.blog-post-content',
		stickyClass: 'is-stuck',
		top: 130
	});

})(jQuery, this);

